
export interface Lead {
  id: string;
  email: string;
  niche: string;
  loss: number;
  teamSize: number;
  manualHours: number;
  timestamp: number;
  enrichedData?: string;
}

export interface User {
  name: string;
  role: string;
}

export interface StrategyResult {
  content: string;
  niche: string;
}

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
  maps?: {
    uri: string;
    title: string;
    placeAnswerSources?: {
      reviewSnippets?: {
        text: string;
        uri: string;
      }[];
    };
  };
}

export interface SearchResponse {
  text: string;
  chunks: GroundingChunk[];
}

export interface MapsResponse {
  text: string;
  chunks: GroundingChunk[];
}

export interface AEOHealthResult {
  score: number;
  analysis: string;
  citations: GroundingChunk[];
}
