
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { LogOut, Activity, Globe2, Shield, Info } from 'lucide-react';
import { BRAND } from '../constants';

interface LayoutProps {
  children?: React.ReactNode;
  isAuthenticated: boolean;
  onLogout: () => void;
  user?: { name: string };
}

export const Navbar: React.FC<LayoutProps> = ({ isAuthenticated, user, onLogout }) => {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <nav className="fixed top-0 w-full z-50 border-b border-white/5 bg-slate-900/80 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-4 group">
          <div className="text-2xl font-black tracking-tighter text-white">
            AIGB<span className="text-cyan-400">SYSTEMS</span>
          </div>
          <div className="hidden md:block h-4 w-px bg-slate-700 mx-2"></div>
          <div className="hidden md:flex flex-col text-left">
            <span className="text-[8px] font-black uppercase text-slate-500 tracking-widest leading-none">Basel Hub</span>
            <span className="text-[8px] font-black uppercase text-slate-500 tracking-widest leading-none">Wyoming LLC</span>
          </div>
        </Link>

        <div className="hidden lg:flex space-x-10 text-[10px] font-bold uppercase tracking-widest text-slate-400">
          <Link to="/" className={`hover:text-cyan-400 transition-colors ${location.pathname === '/' ? 'text-cyan-400' : ''}`}>Public Hub</Link>
          {isAuthenticated && (
            <>
              <Link to="/account/warroom" className={`hover:text-cyan-400 transition-colors ${location.pathname.includes('/warroom') ? 'text-cyan-400' : ''}`}>War Room</Link>
              <Link to="/account/intel" className={`hover:text-cyan-400 transition-colors ${location.pathname.includes('/intel') ? 'text-cyan-400' : ''}`}>Lead Intel</Link>
            </>
          )}
        </div>

        <div className="flex items-center gap-4">
          {!isAuthenticated ? (
            <button 
              onClick={() => navigate('/auth/login')}
              className="px-6 py-2.5 bg-cyan-400 rounded-xl text-[10px] font-black uppercase text-slate-900 hover:bg-white transition-all shadow-lg shadow-cyan-400/20"
            >
              Identity Link
            </button>
          ) : (
            <div className="flex items-center gap-4">
              <span className="text-[10px] font-black text-white uppercase tracking-wider">{user?.name}</span>
              <button onClick={onLogout} className="p-2 hover:bg-red-500/10 rounded-lg transition-colors group">
                <LogOut className="w-4 h-4 text-slate-500 group-hover:text-red-400" />
              </button>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export const Footer: React.FC = () => (
  <footer className="max-w-7xl mx-auto px-6 py-20 border-t border-white/5 opacity-60">
    <div className="flex flex-col md:flex-row justify-between items-center gap-10">
      <div className="flex flex-col gap-2 text-left">
        <p className="text-[10px] font-black uppercase tracking-[0.3em] text-white">
          &copy; {new Date().getFullYear()} AIGB Systems LLC
        </p>
        <p className="text-[9px] font-bold uppercase tracking-[0.1em] text-cyan-400">
          {BRAND.compliance} | Wyoming Corporate Node: 2026-X88
        </p>
        <Link to="/compliance" className="text-[9px] font-bold uppercase text-slate-500 hover:text-cyan-400 transition-colors mt-2 flex items-center gap-1">
          <Info className="w-3 h-3" /> EU AI Act Article 50 Disclosure
        </Link>
      </div>
      <div className="flex gap-8 text-[9px] font-black uppercase tracking-widest">
        <span className="flex items-center gap-2 text-slate-400">
          <div className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div> 
          Basel Node
        </span>
        <span className="flex items-center gap-2 text-slate-400">
          <div className="w-1.5 h-1.5 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div> 
          Wyoming LLC
        </span>
      </div>
    </div>
  </footer>
);
