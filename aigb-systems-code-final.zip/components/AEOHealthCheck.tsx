
import React, { useState } from 'react';
import { Search, AlertTriangle, CheckCircle, Loader2, ExternalLink, Globe, Sparkles, X, FileText } from 'lucide-react';
import { checkAEOHealth, generateAEORecoveryBrief } from '../services/geminiService';
import { marked } from 'marked';
import { GroundingChunk } from '../types';

export const AEOHealthCheck = () => {
  const [url, setUrl] = useState('');
  const [status, setStatus] = useState<'idle' | 'scanning' | 'complete' | 'error'>('idle');
  const [score, setScore] = useState<number | null>(null);
  const [analysis, setAnalysis] = useState<string>('');
  const [citations, setCitations] = useState<GroundingChunk[]>([]);
  
  const [loadingBrief, setLoadingBrief] = useState(false);
  const [brief, setBrief] = useState<string | null>(null);
  const [showBriefModal, setShowBriefModal] = useState(false);

  const runCheck = async () => {
    if (!url) return;
    setStatus('scanning');
    setScore(null);
    setAnalysis('');
    setCitations([]);

    try {
      const result = await checkAEOHealth(url);
      setScore(result.score || 15);
      setAnalysis(result.analysis || "Analysis pending detailed synchronization.");
      setCitations(result.citations || []);
      setStatus('complete');
    } catch (error) {
      console.error("AEO Check Error:", error);
      setStatus('error');
    }
  };

  const handleGenerateBrief = async () => {
    if (!url || score === null) return;
    setLoadingBrief(true);
    try {
      const result = await generateAEORecoveryBrief(url, score);
      setBrief(result || "Generation failed.");
      setShowBriefModal(true);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingBrief(false);
    }
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 p-8 rounded-[40px] relative overflow-hidden shadow-2xl backdrop-blur-md">
      <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 blur-3xl rounded-full pointer-events-none"></div>
      
      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-2">
          <Globe className="w-5 h-5 text-cyan-400" />
          <h3 className="text-xl font-black text-white uppercase tracking-tighter italic">AEO Health Check</h3>
        </div>
        <p className="text-slate-400 text-xs mb-6 font-medium">Is your brand being cited by AI agents? Running low-latency Search Grounding scan.</p>
        
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <input 
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && runCheck()}
            placeholder="Enter domain (e.g. yourcompany.com)"
            className="flex-1 bg-slate-950 border border-slate-700 rounded-2xl px-6 py-4 text-sm text-white outline-none focus:border-cyan-400 transition-all placeholder:text-slate-600 shadow-inner"
          />
          <button 
            onClick={runCheck}
            disabled={status === 'scanning'}
            className="bg-cyan-400 text-slate-900 px-10 py-4 rounded-2xl font-black uppercase text-xs tracking-widest hover:bg-white transition-all disabled:opacity-50 flex items-center justify-center gap-2 shadow-lg shadow-cyan-400/20 active:scale-95"
          >
            {status === 'scanning' ? <Loader2 className="w-4 h-4 animate-spin"/> : <Search className="w-4 h-4"/>}
            {status === 'scanning' ? 'Scanning...' : 'Analyze'}
          </button>
        </div>

        {status === 'error' && (
          <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl text-red-400 text-xs font-bold animate-fadeIn">
            Neural Handshake Failed. Please verify connectivity or check domain format.
          </div>
        )}

        {status === 'complete' && score !== null && (
          <div className="space-y-6 animate-fadeIn">
            <div className="bg-slate-950/50 border border-slate-800 rounded-3xl p-6 shadow-xl">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Visibility Index</span>
                <span className={`text-2xl font-black ${score > 50 ? 'text-green-400' : 'text-red-400'}`}>{score}<span className="text-sm opacity-50">/100</span></span>
              </div>
              <div className="w-full bg-slate-800/50 h-2.5 rounded-full mb-6 overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-1000 ease-out ${score > 50 ? 'bg-green-400 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-red-400 shadow-[0_0_8px_rgba(248,113,113,0.6)]'}`} 
                  style={{ width: `${score}%` }}
                ></div>
              </div>
              
              <div className="space-y-4">
                {score < 50 ? (
                  <div className="flex gap-4 items-start text-red-300 bg-red-400/5 p-5 rounded-2xl border border-red-400/10">
                    <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-xs font-black uppercase mb-1.5 tracking-wide">Critical Visibility Deficit</p>
                      <div className="text-[11px] leading-relaxed opacity-90 prose prose-invert prose-xs max-w-none" dangerouslySetInnerHTML={{ __html: marked.parse(analysis) }} />
                    </div>
                  </div>
                ) : (
                  <div className="flex gap-4 items-start text-green-300 bg-green-400/5 p-5 rounded-2xl border border-green-400/10">
                    <CheckCircle className="w-5 h-5 shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-xs font-black uppercase mb-1.5 tracking-wide">Authoritative Presence Detected</p>
                      <div className="text-[11px] leading-relaxed opacity-90 prose prose-invert prose-xs max-w-none" dangerouslySetInnerHTML={{ __html: marked.parse(analysis) }} />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {citations.length > 0 && (
              <div className="px-2">
                <h4 className="text-[9px] font-black text-slate-500 uppercase tracking-[0.2em] mb-3">Grounding Answer Sources</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {citations.slice(0, 4).map((chunk, i) => chunk.web && (
                    <a 
                      key={i} 
                      href={chunk.web.uri} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center justify-between p-4 bg-slate-800/20 border border-slate-800/50 rounded-2xl hover:bg-slate-800 hover:border-cyan-400/30 transition-all group shadow-sm"
                    >
                      <span className="text-[10px] font-bold text-slate-400 group-hover:text-white truncate max-w-[80%]">
                        {chunk.web.title || chunk.web.uri}
                      </span>
                      <ExternalLink className="w-3.5 h-3.5 text-slate-600 group-hover:text-cyan-400" />
                    </a>
                  ))}
                </div>
              </div>
            )}
            
            <button 
              onClick={handleGenerateBrief}
              disabled={loadingBrief}
              className="w-full py-5 bg-gradient-to-r from-slate-900 to-slate-800 border border-cyan-400/20 text-cyan-400 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:border-cyan-400 hover:shadow-[0_0_20px_rgba(34,211,238,0.1)] transition-all flex items-center justify-center gap-2"
            >
              {loadingBrief ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
              Generate Detailed AEO Recovery Brief
            </button>
          </div>
        )}
      </div>

      {/* Brief Modal */}
      {showBriefModal && brief && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 backdrop-blur-2xl bg-black/60 animate-fadeIn">
          <div className="bg-slate-950 border border-slate-800 w-full max-w-2xl rounded-[48px] shadow-3xl flex flex-col max-h-[85vh] overflow-hidden">
            <div className="p-10 border-b border-slate-900 flex justify-between items-center bg-slate-900/30">
               <div className="flex items-center gap-4">
                 <div className="p-3 bg-cyan-400/10 rounded-2xl">
                    <FileText className="w-6 h-6 text-cyan-400" />
                 </div>
                 <h3 className="text-xl font-black text-white uppercase tracking-tighter">Technical AEO Brief</h3>
               </div>
               <button onClick={() => setShowBriefModal(false)} className="p-2 text-slate-500 hover:text-white transition-colors">
                 <X className="w-8 h-8" />
               </button>
            </div>
            <div className="p-12 overflow-y-auto flex-1 prose prose-invert max-w-none custom-scrollbar bg-slate-950/50">
               <div dangerouslySetInnerHTML={{ __html: marked.parse(brief) }} />
            </div>
            <div className="p-8 border-t border-slate-900 text-center bg-slate-900/10">
               <p className="text-[9px] font-bold text-slate-600 uppercase tracking-widest">
                 Confidential Analysis Generated by Gemini-3-Flash
               </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
