
import { GoogleGenAI, Type } from "@google/genai";
import { SearchResponse, MapsResponse, AEOHealthResult } from "../types";

const getAIClient = () => {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
};

/**
 * Generates an AEO strategy roadmap.
 */
export const generateAEOStrategy = async (niche: string) => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-flash-lite-latest',
    contents: `Generate a high-authority AEO (Answer Engine Optimization) roadmap for a business in the '${niche}' industry. 
    Focus on LLM citations, agentic workflows, and semantic relevance. 
    Format the response in clean Markdown with clear headings and actionable bullet points. 
    Tone: Visionary, strategic, and authoritative.`,
    config: {
      temperature: 0.7,
      topP: 0.95,
    }
  });
  return response.text;
};

/**
 * Generates a detailed recovery brief for AEO visibility deficits.
 */
export const generateAEORecoveryBrief = async (url: string, score: number) => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `The website ${url} has an AI visibility score of ${score}/100. 
    Create a technical AEO Recovery Brief. 
    Address: 
    1. Schema.org enhancements.
    2. Knowledge Graph entity validation.
    3. Sentiment calibration for LLM indexing.
    Tone: Highly technical, executive level. Format: Markdown.`,
  });
  return response.text;
};

/**
 * Generates a Roadmap based on Friction Audit values.
 */
export const generateFrictionRoadmap = async (teamSize: number, hours: number, loss: number) => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `An organization with ${teamSize} personnel is losing $${loss.toLocaleString()} annually due to ${hours} hours/week of manual operational friction.
    Generate a 3-step 'Neural Recovery Roadmap' to automate this friction.
    Include specific agentic workflow suggestions and estimated time to ROI.
    Format: Markdown.`,
  });
  return response.text;
};

export const enrichLeadData = async (email: string, niche: string) => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-flash-lite-latest',
    contents: `Research and enrich data for a lead: ${email} in the ${niche} sector. 
    Identify potential tech stack, competitors, and specific operational friction points. 
    Use Google Search grounding to find real-time public data.`,
    config: {
      tools: [{ googleSearch: {} }]
    }
  });
  return response.text;
};

export const generateSalesBrief = async (email: string, niche: string, loss: number, enrichment?: string) => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Create a high-conversion Neural Sales Brief for ${email} in the ${niche} industry. 
    Annual revenue leak: $${loss.toLocaleString()}. 
    Enriched Context: ${enrichment || "No additional data available."}
    Use ROI-focused language, evidence-based reasoning, and an assumptive close. 
    Format in Markdown.`,
    config: {
      temperature: 0.8,
      thinkingConfig: { thinkingBudget: 4000 }
    }
  });
  return response.text;
};

export const checkAEOHealth = async (url: string): Promise<AEOHealthResult> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-flash-lite-latest',
    contents: `Analyze the AEO (Answer Engine Optimization) health and visibility of the website: ${url}. 
    Identify if this brand or domain is frequently cited, mentioned, or used as a source in high-authority AI-style answers. 
    Return a score out of 100 and a 2-sentence executive summary.`,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  const text = response.text || "";
  const scoreMatch = text.match(/(\d+)\/100/);
  const score = scoreMatch ? parseInt(scoreMatch[1]) : 0;

  return {
    score,
    analysis: text,
    citations: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};

export const strategicSearch = async (query: string): Promise<SearchResponse> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: query,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  return {
    text: response.text || "Analysis complete.",
    chunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};

export const mapsIntelligence = async (query: string, lat?: number, lng?: number): Promise<MapsResponse> => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: `Analyze: "${query}". Include sentiment, operational status, and location advantages.`,
    config: {
      tools: [{ googleMaps: {} }],
      toolConfig: {
        retrievalConfig: {
          latLng: lat && lng ? { latitude: lat, longitude: lng } : undefined
        }
      }
    },
  });

  return {
    text: response.text || "Location intelligence gathered.",
    chunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};

export const getQuickInsight = async (niche: string) => {
  const ai = getAIClient();
  const response = await ai.models.generateContent({
    model: 'gemini-flash-lite-latest',
    contents: `Give a single, one-sentence tactical automation tip for the ${niche} industry that provides immediate ROI.`,
    config: {
      temperature: 1,
      topP: 0.95,
    }
  });
  return response.text;
};
