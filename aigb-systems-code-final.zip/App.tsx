
import React, { useState } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Navbar, Footer } from './components/Layout';
import Home from './pages/Home';
import WarRoom from './pages/WarRoom';
import LeadIntel from './pages/LeadIntel';
import Auth from './pages/Auth';
import Compliance from './pages/Compliance';

const App: React.FC = () => {
  const [auth, setAuth] = useState(false);
  const user = { name: "Lars Navigator", role: "Sales Architect" };

  return (
    <Router>
      <div className="min-h-screen bg-[#0F172A] text-slate-50 selection:bg-cyan-400/30 selection:text-cyan-200 font-sans antialiased relative overflow-x-hidden">
        {/* Background Decorative Grid */}
        <div className="fixed inset-0 bg-grid-pattern pointer-events-none opacity-20"></div>
        <div className="fixed top-0 left-1/4 w-[1px] h-full bg-white/5 pointer-events-none"></div>
        <div className="fixed top-0 right-1/4 w-[1px] h-full bg-white/5 pointer-events-none"></div>

        <Navbar isAuthenticated={auth} user={user} onLogout={() => setAuth(false)} />
        
        <main className="relative z-10">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/auth/login" element={<Auth setAuth={setAuth} />} />
            <Route path="/compliance" element={<Compliance />} />
            
            {/* Protected Routes */}
            <Route 
              path="/account/warroom" 
              element={auth ? <WarRoom /> : <Navigate to="/auth/login" />} 
            />
            <Route 
              path="/account/intel" 
              element={auth ? <LeadIntel /> : <Navigate to="/auth/login" />} 
            />

            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </main>

        <Footer />

        <style>{`
          @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
          .animate-fadeIn { animation: fadeIn 0.8s ease-out forwards; }
          
          .custom-scrollbar::-webkit-scrollbar { width: 4px; }
          .custom-scrollbar::-webkit-scrollbar-track { background: rgba(15, 23, 42, 0.5); }
          .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(34, 211, 238, 0.2); border-radius: 10px; }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(34, 211, 238, 0.4); }

          input[type='range']::-webkit-slider-thumb {
            -webkit-appearance: none;
            appearance: none;
            width: 16px;
            height: 16px;
            background: #22D3EE;
            cursor: pointer;
            border-radius: 50%;
            border: 2px solid #0F172A;
            box-shadow: 0 0 10px rgba(34, 211, 238, 0.5);
          }
        `}</style>
      </div>
    </Router>
  );
}

export default App;
