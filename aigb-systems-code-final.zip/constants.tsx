
import React from 'react';

export const BRAND = {
  name: "AIGB SYSTEMS",
  legal: "AIGB Systems LLC",
  tagline: "Swiss Precision. US Scaling.",
  accent: "#22D3EE", 
  compliance: "EU AI Act Art. 50 Compliant"
};

export const INITIAL_LEADS: any[] = [
  { id: '1', email: "contact@basel-legal.ch", niche: "Legal Services", loss: 142000, teamSize: 12, manualHours: 15, timestamp: Date.now() - 86400000 },
  { id: '2', email: "ops@wyoming-logistics.com", niche: "Logistics", loss: 288000, teamSize: 25, manualHours: 10, timestamp: Date.now() - 172800000 },
  { id: '3', email: "ceo@swiss-fintech.ch", niche: "Fintech", loss: 412000, teamSize: 18, manualHours: 20, timestamp: Date.now() - 259200000 },
];
