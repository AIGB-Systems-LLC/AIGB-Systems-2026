
import React, { useState } from 'react';
import { Search, Sparkles, X, Loader2, ClipboardCheck, ArrowUpRight, SearchCheck, Check } from 'lucide-react';
import { generateSalesBrief, enrichLeadData } from '../services/geminiService';
import { INITIAL_LEADS } from '../constants';
import { marked } from 'marked';

const LeadIntel: React.FC = () => {
  const [leads, setLeads] = useState(INITIAL_LEADS);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLead, setSelectedLead] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isEnriching, setIsEnriching] = useState(false);
  const [brief, setBrief] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [copied, setCopied] = useState(false);
  
  const [syncingCRM, setSyncingCRM] = useState(false);
  const [syncSuccess, setSyncSuccess] = useState(false);

  const handleProcessLead = async (lead: any) => {
    setSelectedLead(lead);
    setShowModal(true);
    setBrief("");
    setSyncSuccess(false);
    
    // Step 1: Enrich
    setIsEnriching(true);
    let enrichment = "";
    try {
      enrichment = await enrichLeadData(lead.email, lead.niche);
    } catch (e) {
      console.warn("Enrichment failed, proceeding with basic brief.");
    } finally {
      setIsEnriching(false);
    }

    // Step 2: Generate Brief
    setIsGenerating(true);
    try {
      const text = await generateSalesBrief(lead.email, lead.niche, lead.loss, enrichment);
      setBrief(text || "");
    } catch (e) {
      setBrief("Brief generation failed. Infrastructure link down.");
    } finally {
      setIsGenerating(false);
    }
  };

  const copyBrief = () => {
    const plainText = brief.replace(/[#*]/g, '');
    navigator.clipboard.writeText(plainText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePushToCRM = () => {
    setSyncingCRM(true);
    setTimeout(() => {
      setSyncingCRM(false);
      setSyncSuccess(true);
      setTimeout(() => setSyncSuccess(false), 3000);
    }, 2000);
  };

  const filteredLeads = leads.filter(l => 
    l.email.toLowerCase().includes(searchTerm.toLowerCase()) || 
    l.niche.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-6 py-32 text-left min-h-screen">
      <div className="mb-16">
        <h1 className="text-5xl font-black text-white uppercase tracking-tighter leading-none mb-4">Lead Intelligence</h1>
        <p className="text-slate-400 font-medium">Internal command module for Neural Sales Briefs and Prospect DNA enrichment.</p>
      </div>

      <div className="bg-slate-900/50 border border-slate-800 rounded-[48px] overflow-hidden shadow-2xl backdrop-blur-sm">
        <div className="p-10 border-b border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
           <h3 className="font-black text-white uppercase tracking-tighter text-lg">Operational Audit Nodes</h3>
           <div className="relative w-full md:w-auto">
              <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <input 
                type="text" 
                placeholder="Search Identity or Niche..." 
                className="bg-slate-950 border border-slate-800 rounded-2xl pl-12 pr-6 py-3 text-xs text-white outline-none focus:border-cyan-400 w-full md:w-80 transition-all" 
                onChange={(e) => setSearchTerm(e.target.value)} 
              />
           </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left">
             <thead>
                <tr className="bg-slate-950/50 text-[10px] font-black text-slate-500 uppercase tracking-widest border-b border-slate-800">
                   <th className="px-10 py-5">Prospect Node</th>
                   <th className="px-10 py-5">Niche Vertical</th>
                   <th className="px-10 py-5">Identified Leak</th>
                   <th className="px-10 py-5 text-right">Actions</th>
                </tr>
             </thead>
             <tbody className="divide-y divide-slate-800">
                {filteredLeads.map(lead => (
                  <tr key={lead.id} className="hover:bg-cyan-400/[0.03] transition-colors group">
                     <td className="px-10 py-6">
                       <div className="font-bold text-white text-sm">{lead.email}</div>
                       <div className="text-[10px] text-slate-500 font-mono mt-1">UUID: {lead.id}-XND</div>
                     </td>
                     <td className="px-10 py-6">
                       <span className="text-xs font-bold text-slate-400 uppercase tracking-widest bg-slate-800 px-3 py-1 rounded-full border border-slate-700">
                         {lead.niche}
                       </span>
                     </td>
                     <td className="px-10 py-6 font-black text-red-400/90 tracking-tighter text-lg">
                       ${lead.loss.toLocaleString()}
                     </td>
                     <td className="px-10 py-6 text-right">
                        <button 
                          onClick={() => handleProcessLead(lead)} 
                          className="bg-cyan-400 text-slate-900 px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white transition-all flex items-center gap-2 ml-auto shadow-lg shadow-cyan-400/10"
                        >
                          Enrich & Brief <Sparkles className="w-3.5 h-3.5" />
                        </button>
                     </td>
                  </tr>
                ))}
             </tbody>
          </table>
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 backdrop-blur-xl bg-black/70 animate-fadeIn">
          <div className="bg-slate-950 border border-slate-800 w-full max-w-4xl rounded-[56px] shadow-3xl flex flex-col max-h-[90vh] overflow-hidden">
            <div className="p-10 border-b border-slate-900 flex justify-between items-center bg-slate-900/20">
               <div>
                 <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Neural Intelligence Brief</h3>
                 <p className="text-[10px] font-black text-cyan-400 uppercase tracking-widest mt-1">UUID: {selectedLead?.id}-XND | SECURE LINK</p>
               </div>
               <button onClick={() => setShowModal(false)} className="p-2 text-slate-500 hover:text-white transition-colors">
                 <X className="w-8 h-8" />
               </button>
            </div>
            
            <div className="p-12 overflow-y-auto flex-1 bg-slate-950 prose prose-invert max-w-none custom-scrollbar">
              {isEnriching ? (
                <div className="py-20 flex flex-col items-center justify-center gap-6">
                   <div className="relative">
                      <SearchCheck className="w-12 h-12 text-blue-400 animate-pulse" />
                   </div>
                   <p className="text-blue-400 font-black uppercase tracking-widest text-[10px]">Step 1: Enriching Prospect DNA...</p>
                </div>
              ) : isGenerating ? (
                <div className="py-20 flex flex-col items-center justify-center gap-6">
                   <div className="relative">
                      <Loader2 className="w-12 h-12 text-cyan-400 animate-spin" />
                   </div>
                   <p className="text-cyan-400 font-black uppercase tracking-widest text-[10px]">Step 2: Synthesizing High-Conversion Brief...</p>
                </div>
              ) : (
                <div dangerouslySetInnerHTML={{ __html: marked.parse(brief) }} />
              )}
            </div>

            <div className="p-10 border-t border-slate-900 flex flex-col sm:flex-row justify-end gap-4 bg-slate-900/30">
               <button onClick={copyBrief} disabled={isGenerating || isEnriching} className="px-8 py-4 border border-slate-700 rounded-2xl text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-white transition-all">
                 {copied ? "Copied" : "Copy Content"}
               </button>
               <button 
                onClick={handlePushToCRM}
                disabled={isGenerating || isEnriching || syncingCRM}
                className={`px-10 py-4 ${syncSuccess ? 'bg-green-500' : 'bg-cyan-400'} text-slate-900 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-2xl hover:bg-white transition-all flex items-center justify-center gap-2 min-w-[180px]`}
               >
                 {syncingCRM ? (
                    <><Loader2 className="w-4 h-4 animate-spin" /> Syncing...</>
                 ) : syncSuccess ? (
                    <><Check className="w-4 h-4" /> Synced</>
                 ) : (
                    <><ArrowUpRight className="w-4 h-4" /> Push to CRM</>
                 )}
               </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LeadIntel;
