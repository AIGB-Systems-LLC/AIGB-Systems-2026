
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Fingerprint, Loader2 } from 'lucide-react';

interface AuthProps {
  setAuth: (val: boolean) => void;
}

const Auth: React.FC<AuthProps> = ({ setAuth }) => {
  const navigate = useNavigate();
  const [isLinking, setIsLinking] = useState(false);

  const handleAuth = () => {
    setIsLinking(true);
    // Simulate handshake
    setTimeout(() => {
      setAuth(true);
      navigate('/account/warroom');
    }, 1500);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-6">
       <div className="bg-slate-900 border border-slate-800 p-16 rounded-[60px] max-w-md w-full text-center shadow-2xl relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          
          <div className="w-20 h-20 bg-slate-950 rounded-[28px] flex items-center justify-center mx-auto mb-10 border border-slate-800 shadow-inner">
            <Shield className="w-10 h-10 text-cyan-400" />
          </div>

          <div className="text-4xl font-black tracking-tighter text-white mb-2">AIGB<span className="text-cyan-400">SYSTEMS</span></div>
          <p className="text-slate-500 text-[9px] font-black uppercase tracking-[0.4em] mb-12">Intelligence Handshake Required</p>
          
          <button 
            onClick={handleAuth} 
            disabled={isLinking}
            className="w-full bg-cyan-400 text-slate-900 py-5 rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-cyan-400/20 hover:bg-white transition-all flex items-center justify-center gap-3"
          >
            {isLinking ? <Loader2 className="w-5 h-5 animate-spin" /> : <Fingerprint className="w-5 h-5" />}
            {isLinking ? "Verifying..." : "Initialize Link"}
          </button>

          <p className="mt-8 text-[9px] text-slate-600 font-bold uppercase tracking-widest">
            SECURED BY AIGB QUANTUM-LEDGER
          </p>
       </div>
    </div>
  );
};

export default Auth;
