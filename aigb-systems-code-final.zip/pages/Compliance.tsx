
import React from 'react';
import { Shield, Lock, Scale, UserCheck } from 'lucide-react';

const Compliance: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-6 py-32 animate-fadeIn">
      <div className="flex items-center gap-6 mb-12">
        <div className="p-4 bg-cyan-400/10 rounded-[32px] border border-cyan-400/20">
          <Shield className="w-12 h-12 text-cyan-400" />
        </div>
        <div>
          <h1 className="text-4xl font-black text-white uppercase tracking-tighter">AI Compliance Node</h1>
          <p className="text-slate-500 text-sm font-bold uppercase tracking-widest">EU AI Act (CH/EU) Art. 50 Integration</p>
        </div>
      </div>

      <div className="space-y-12">
        <section className="bg-slate-900/50 border border-slate-800 p-10 rounded-[40px]">
          <h2 className="text-xl font-black text-white mb-6 uppercase tracking-tighter flex items-center gap-3">
            <Lock className="w-5 h-5 text-cyan-400" /> Transparency Obligations
          </h2>
          <div className="text-slate-400 text-sm leading-relaxed space-y-4">
            <p>
              Under Article 50 of the EU AI Act, providers of AI systems must ensure that individuals are informed when they are interacting with an AI system. AIGB Systems operates with 100% neural transparency.
            </p>
            <p>
              The outputs generated on this portal, including <strong>Neural Sales Briefs</strong> and <strong>AEO Strategies</strong>, are synthesized by Google Gemini model variants. These outputs are intended as decision-support tools and should be reviewed by qualified personnel before deployment.
            </p>
          </div>
        </section>

        <section className="bg-slate-900/50 border border-slate-800 p-10 rounded-[40px]">
          <h2 className="text-xl font-black text-white mb-6 uppercase tracking-tighter flex items-center gap-3">
            <Scale className="w-5 h-5 text-cyan-400" /> Human-in-the-Loop Protocol
          </h2>
          <p className="text-slate-400 text-sm leading-relaxed">
            AIGB Systems enforces a "Swiss Precision" standard. While our agentic workflows automate 80% of operational friction, the final 20%—strategic approval and ethical verification—remains under human jurisdiction. Our systems are designed to augment, not replace, human cognitive agency.
          </p>
        </section>

        <section className="bg-slate-900/50 border border-slate-800 p-10 rounded-[40px]">
          <h2 className="text-xl font-black text-white mb-6 uppercase tracking-tighter flex items-center gap-3">
            <UserCheck className="w-5 h-5 text-cyan-400" /> Data Sovereignty
          </h2>
          <p className="text-slate-400 text-sm leading-relaxed">
            Data processed within the Basel Hub is handled according to Swiss DPA and GDPR standards. Local nodes in Switzerland ensure that sensitive operational metrics never traverse insecure channels.
          </p>
        </section>
      </div>

      <div className="mt-16 text-center">
        <p className="text-[10px] font-black uppercase text-slate-600 tracking-[0.4em]">
          Version 2026.1.4 | Basel Core
        </p>
      </div>
    </div>
  );
};

export default Compliance;
