
import React, { useState, useEffect } from 'react';
import { Database, Zap, Activity, Globe2, Shield, Cpu, RefreshCw, Server, AlertCircle, Loader2 } from 'lucide-react';

const StatCard: React.FC<{ label: string, value: string, icon: React.ReactNode, color: string }> = ({ label, value, icon, color }) => (
  <div className="bg-slate-900/50 border border-slate-800 p-8 rounded-3xl group hover:border-cyan-400/30 transition-all">
    <div className={`p-3 rounded-2xl bg-slate-950 w-fit mb-6 text-${color}`}>
      {icon}
    </div>
    <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">{label}</div>
    <div className="text-3xl font-black text-white tracking-tighter">{value}</div>
  </div>
);

const WarRoom: React.FC = () => {
  const [latency, setLatency] = useState(18);
  const [load, setLoad] = useState(14);
  const [isResyncing, setIsResyncing] = useState(false);
  const [logs, setLogs] = useState<string[]>([
    "Neural Bridge Handshake Successful :: Wyoming -> Basel",
    "AEO Health Check Diagnostic :: URL Validation Passed",
    "Lead Enrichment Engine :: Citations Gathered via Google Search",
    "Encryption Layer IV Refreshed :: AES-GCM-256"
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setLatency(prev => Math.max(10, Math.min(40, prev + (Math.random() > 0.5 ? 1 : -1))));
      setLoad(prev => Math.max(5, Math.min(30, prev + (Math.random() > 0.5 ? 2 : -2))));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleResync = () => {
    setIsResyncing(true);
    // Simulate node resync
    setTimeout(() => {
      setLatency(12 + Math.floor(Math.random() * 6));
      setLoad(8 + Math.floor(Math.random() * 6));
      const newLog = `System Recalibration Complete :: Global Node Latency Minimized [${Date.now()}]`;
      setLogs(prev => [newLog, ...prev.slice(0, 3)]);
      setIsResyncing(false);
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-32 text-left">
      <div className="mb-16 flex justify-between items-end">
        <div>
           <span className="text-cyan-400 font-black text-[10px] uppercase tracking-[0.3em] block mb-2">Operational Command</span>
           <h2 className="text-5xl font-black text-white uppercase tracking-tighter">The War Room</h2>
        </div>
        <div className="flex gap-4">
           <button 
            onClick={handleResync}
            disabled={isResyncing}
            className="flex items-center gap-2 px-6 py-3 bg-slate-900 border border-slate-800 rounded-xl text-[10px] font-black uppercase text-slate-400 hover:text-cyan-400 transition-colors disabled:opacity-50"
           >
              {isResyncing ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
              {isResyncing ? "Resyncing..." : "Resync Nodes"}
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <StatCard label="Global Latency" value={`${latency}ms`} icon={<Globe2 className="w-5 h-5" />} color="cyan-400" />
        <StatCard label="Compute Load" value={`${load}%`} icon={<Cpu className="w-5 h-5" />} color="blue-400" />
        <StatCard label="Shield Status" value="Active" icon={<Shield className="w-5 h-5" />} color="green-400" />
        <StatCard label="Model Health" value="Peak" icon={<Activity className="w-5 h-5" />} color="purple-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
         <div className="lg:col-span-2 space-y-8">
            <div className="bg-slate-900/50 border border-slate-800 rounded-[40px] p-12 relative overflow-hidden group">
               <div className="absolute top-0 right-0 p-12 opacity-5 group-hover:opacity-10 transition-opacity">
                  <Database className="w-48 h-48 text-cyan-400" />
               </div>
               <div className="relative z-10">
                 <h3 className="text-2xl font-black text-white uppercase tracking-tighter mb-8 flex items-center gap-4">
                   <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse"></div>
                   Infrastructure Logs
                 </h3>
                 <div className="space-y-4 font-mono text-[10px] text-slate-400 uppercase tracking-widest leading-relaxed">
                   {logs.map((log, idx) => (
                     <div key={idx} className={`flex gap-4 border-b border-slate-800 pb-3 ${idx === 0 ? 'animate-fadeIn' : ''}`}>
                       <span className="text-cyan-400">[{new Date().toLocaleTimeString()}]</span>
                       <span>{log}</span>
                     </div>
                   ))}
                 </div>
               </div>
            </div>

            {/* Neural Status Monitor */}
            <div className="bg-slate-950 border border-slate-800 rounded-[40px] p-12 flex flex-col md:flex-row items-center gap-12">
               <div className="flex-1">
                 <h4 className="text-xl font-black text-white uppercase tracking-tighter mb-4 flex items-center gap-3">
                   <Server className="w-6 h-6 text-green-400" />
                   Neural Engine Status
                 </h4>
                 <p className="text-slate-500 text-sm">Gemini 3 Pro and Flash-Preview nodes are currently operational with zero throttled requests.</p>
               </div>
               <div className="flex gap-8">
                 <div className="text-center">
                    <div className="text-2xl font-black text-white">99.9%</div>
                    <div className="text-[9px] font-black uppercase text-slate-600 tracking-widest mt-1">Uptime</div>
                 </div>
                 <div className="text-center">
                    <div className="text-2xl font-black text-white">2.1s</div>
                    <div className="text-[9px] font-black uppercase text-slate-600 tracking-widest mt-1">Avg Gen Time</div>
                 </div>
               </div>
            </div>
         </div>

         <div className="bg-gradient-to-br from-cyan-600 to-blue-800 rounded-[40px] p-12 text-white shadow-2xl relative overflow-hidden h-fit">
            <div className="absolute top-0 right-0 -mt-10 -mr-10 opacity-10">
              <Zap className="w-64 h-64" />
            </div>
            <AlertCircle className="w-12 h-12 mb-8" />
            <h4 className="text-3xl font-black uppercase leading-[0.85] mb-6">Strategic Continuity</h4>
            <p className="text-sm font-bold opacity-80 leading-relaxed italic mb-8">
              "Infrastructure communication optimized. AEO diagnostic success rates at record levels for Basel-hub deployments."
            </p>
            <div className="space-y-4">
              <div className="h-1.5 w-full bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-white w-4/5 rounded-full"></div>
              </div>
              <div className="flex justify-between text-[10px] font-black uppercase tracking-widest opacity-60">
                <span>Resource Allocation</span>
                <span>80%</span>
              </div>
            </div>
         </div>
      </div>
    </div>
  );
};

export default WarRoom;
