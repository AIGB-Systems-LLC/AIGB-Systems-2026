
import React, { useState, useEffect } from 'react';
import { 
  Activity, Sparkles, Loader2, Search, ExternalLink, Globe, 
  MapPin, Star, MessageSquare, Quote, Navigation, FileText, Download, Zap, Lightbulb, X
} from 'lucide-react';
import { generateAEOStrategy, strategicSearch, mapsIntelligence, getQuickInsight, generateFrictionRoadmap } from '../services/geminiService';
import { AEOHealthCheck } from '../components/AEOHealthCheck';
import { marked } from 'marked';
import { SearchResponse, MapsResponse } from '../types';

const TOPIC_CARDS = [
  { 
    title: "The Future of AEO", 
    desc: "How LLMs are replacing traditional SERP.",
    query: "Current state of Answer Engine Optimization and Gemini search behavior 2026"
  },
  { 
    title: "Swiss Banking Automation", 
    desc: "Precision AI in Basel's financial sector.",
    query: "Latest AI automation trends in Swiss banking and wealth management"
  },
  { 
    title: "Agentic ROI Scaling", 
    desc: "Quantifying the impact of autonomous workers.",
    query: "Business case studies for agentic workflow ROI in enterprise 2025-2026"
  }
];

const Home: React.FC = () => {
  const [teamSize, setTeamSize] = useState(12);
  const [hours, setHours] = useState(15);
  const [niche, setNiche] = useState("");
  const [strategy, setStrategy] = useState<string | null>(null);
  const [loadingAEO, setLoadingAEO] = useState(false);

  // Search Grounding State
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResult, setSearchResult] = useState<SearchResponse | null>(null);
  const [loadingSearch, setLoadingSearch] = useState(false);

  // Maps Grounding State
  const [locationQuery, setLocationQuery] = useState("");
  const [mapsResult, setMapsResult] = useState<MapsResponse | null>(null);
  const [loadingMaps, setLoadingMaps] = useState(false);
  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);

  // Quick Insight State
  const [quickInsight, setQuickInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);

  // Audit Roadmap State
  const [loadingAudit, setLoadingAudit] = useState(false);
  const [auditRoadmap, setAuditRoadmap] = useState<string | null>(null);
  const [showAuditModal, setShowAuditModal] = useState(false);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => console.log("Location access denied")
      );
    }
  }, []);

  const annualLoss = teamSize * hours * 45 * 52;

  const handleGenerateAEO = async () => {
    if (!niche) return;
    setLoadingAEO(true);
    setStrategy(null);
    try {
      const text = await generateAEOStrategy(niche);
      setStrategy(text || "No strategy generated.");
    } catch (error) {
      setStrategy("Strategic layer sync failed.");
    } finally {
      setLoadingAEO(false);
    }
  };

  const handleStrategicSearch = async (query: string = searchQuery) => {
    if (!query) return;
    setLoadingSearch(true);
    setSearchResult(null);
    try {
      const result = await strategicSearch(query);
      setSearchResult(result);
      if (query !== searchQuery) setSearchQuery(query);
    } catch (error) {
      console.error(error);
    } finally {
      setLoadingSearch(false);
    }
  };

  const handleMapsRecon = async () => {
    if (!locationQuery) return;
    setLoadingMaps(true);
    setMapsResult(null);
    try {
      const result = await mapsIntelligence(locationQuery, userLocation?.lat, userLocation?.lng);
      setMapsResult(result);
    } catch (error) {
      console.error(error);
    } finally {
      setLoadingMaps(false);
    }
  };

  const handleQuickInsight = async () => {
    if (!niche) return;
    setLoadingInsight(true);
    setQuickInsight(null);
    try {
      const text = await getQuickInsight(niche);
      setQuickInsight(text || "No insight available.");
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingInsight(false);
    }
  };

  const handlePlugTheLeak = async () => {
    setLoadingAudit(true);
    try {
      const roadmap = await generateFrictionRoadmap(teamSize, hours, annualLoss);
      setAuditRoadmap(roadmap || "Roadmap generation failed.");
      setShowAuditModal(true);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingAudit(false);
    }
  };

  const downloadAuditReport = () => {
    const reportContent = `
AIGB SYSTEMS | FRICTION AUDIT REPORT
-----------------------------------
Personnel Impacted: ${teamSize}
Manual Overhead: ${hours} hrs/week
ESTIMATED ANNUAL REVENUE LEAK: $${annualLoss.toLocaleString()}

Generated on: ${new Date().toLocaleDateString()}
Node: Basel Core Intelligence
    `;
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Audit_Report_${Date.now()}.txt`;
    link.click();
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-32">
      {/* Hero Section */}
      <div className="text-center mb-24 animate-fadeIn">
        <div className="inline-flex items-center gap-3 px-4 py-2 bg-slate-900 border border-slate-800 rounded-full mb-8">
          <Activity className="w-4 h-4 text-cyan-400 animate-pulse" />
          <span className="text-cyan-400 font-black text-[10px] uppercase tracking-[0.3em]">Autonomous Intelligence Infrastructure</span>
        </div>
        
        <h1 className="text-6xl md:text-8xl font-black mb-8 leading-[0.9] text-white tracking-tighter">
          Automate. <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-white">Reclaim Edge.</span>
        </h1>
        <p className="max-w-2xl mx-auto text-slate-400 text-lg mb-10">
          Precision-engineered automation for Swiss reliability and American scale. 
          The command center for your operational evolution.
        </p>
      </div>

      {/* INTELLIGENCE PULSE (Fast AI Responses) */}
      <section className="mb-20 max-w-4xl mx-auto text-center">
        <div className="bg-slate-900/40 border border-slate-800 rounded-3xl p-6 backdrop-blur-sm flex flex-col md:flex-row items-center gap-6">
           <div className="p-3 bg-cyan-400/10 rounded-2xl">
              <Lightbulb className="w-6 h-6 text-cyan-400" />
           </div>
           <div className="flex-1 text-left">
              <h4 className="text-xs font-black uppercase tracking-widest text-slate-500 mb-1">Quick Intelligence Pulse</h4>
              <p className="text-sm text-slate-300">
                {quickInsight || (loadingInsight ? "Synchronizing with low-latency flash nodes..." : "Enter an industry below to trigger a tactical automation insight.")}
              </p>
           </div>
           {niche && !loadingInsight && (
             <button onClick={handleQuickInsight} className="text-[10px] font-black uppercase tracking-widest text-cyan-400 hover:text-white transition-colors">
               Refresh Insight
             </button>
           )}
        </div>
      </section>

      {/* AEO HEALTH CHECK - Lead Magnet */}
      <section className="mb-32 max-w-4xl mx-auto">
        <AEOHealthCheck />
      </section>

      {/* STRATEGIC INTELLIGENCE TERMINAL */}
      <section className="mb-16 relative">
        <div className="bg-slate-900/50 border border-slate-800 rounded-[48px] p-8 md:p-12 shadow-3xl overflow-hidden">
          <div className="flex flex-col md:flex-row items-center gap-8 mb-12">
            <div className="flex-1">
              <h2 className="text-3xl font-black text-white uppercase tracking-tighter italic flex items-center gap-3">
                <Globe className="w-8 h-8 text-cyan-400" />
                Strategic Intel Terminal
              </h2>
              <p className="text-slate-500 text-sm mt-2">Verified real-time information with Google Search grounding.</p>
            </div>
            <div className="w-full md:w-auto flex gap-3 bg-slate-950 p-3 rounded-3xl border border-slate-800 shadow-inner">
              <input 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleStrategicSearch()}
                placeholder="Query any industry topic..." 
                className="bg-transparent border-none text-white text-sm outline-none px-4 w-full md:w-80"
              />
              <button 
                onClick={() => handleStrategicSearch()}
                disabled={loadingSearch}
                className="bg-cyan-400 text-slate-900 p-3 rounded-2xl hover:bg-white transition-all shadow-lg shadow-cyan-400/20"
              >
                {loadingSearch ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {searchResult && (
            <div className="grid lg:grid-cols-3 gap-8 animate-fadeIn">
              <div className="lg:col-span-2 p-10 bg-slate-950/50 rounded-[32px] border border-slate-800/50 prose prose-invert max-w-none shadow-xl">
                <div dangerouslySetInnerHTML={{ __html: marked.parse(searchResult.text) }} />
              </div>
              
              <div className="space-y-6">
                <h4 className="text-[10px] font-black text-cyan-400 uppercase tracking-[0.2em] flex items-center gap-2">
                  <ExternalLink className="w-3 h-3" /> Source Citations
                </h4>
                <div className="space-y-3">
                  {searchResult.chunks.map((chunk, idx) => (
                    chunk.web && (
                      <a 
                        key={idx} 
                        href={chunk.web.uri} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="block p-4 bg-slate-800/30 hover:bg-slate-800/60 border border-slate-700/50 rounded-2xl transition-all group"
                      >
                        <div className="text-xs font-bold text-white group-hover:text-cyan-400 transition-colors line-clamp-1">{chunk.web.title}</div>
                        <div className="text-[9px] text-slate-500 truncate mt-1">{chunk.web.uri}</div>
                      </a>
                    )
                  ))}
                </div>
              </div>
            </div>
          )}

          {!searchResult && !loadingSearch && (
            <div className="grid md:grid-cols-3 gap-6">
              {TOPIC_CARDS.map((card, i) => (
                <button 
                  key={i}
                  onClick={() => handleStrategicSearch(card.query)}
                  className="text-left p-8 bg-slate-950/50 border border-slate-800 rounded-[32px] hover:border-cyan-400/50 transition-all group"
                >
                  <Globe className="w-6 h-6 text-slate-600 mb-6 group-hover:text-cyan-400 transition-colors" />
                  <h4 className="font-black text-white uppercase text-sm mb-2">{card.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">{card.desc}</p>
                </button>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* LOCATION RECON TERMINAL */}
      <section className="mb-32 relative">
        <div className="bg-slate-900/50 border border-slate-800 rounded-[48px] p-8 md:p-12 shadow-3xl overflow-hidden border-t-cyan-400/20">
          <div className="flex flex-col md:flex-row items-center gap-8 mb-12">
            <div className="flex-1">
              <h2 className="text-3xl font-black text-white uppercase tracking-tighter italic flex items-center gap-3">
                <MapPin className="w-8 h-8 text-red-400" />
                Location Recon Terminal
              </h2>
              <p className="text-slate-500 text-sm mt-2">Pull live Google Maps reviews and physical entity status.</p>
            </div>
            <div className="w-full md:w-auto flex gap-3 bg-slate-950 p-3 rounded-3xl border border-slate-800 shadow-inner">
              <input 
                value={locationQuery}
                onChange={(e) => setLocationQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleMapsRecon()}
                placeholder="Business Name or Address..." 
                className="bg-transparent border-none text-white text-sm outline-none px-4 w-full md:w-80"
              />
              <button 
                onClick={() => handleMapsRecon()}
                disabled={loadingMaps}
                className="bg-red-400 text-slate-900 p-3 rounded-2xl hover:bg-white transition-all shadow-lg shadow-red-400/20"
              >
                {loadingMaps ? <Loader2 className="w-5 h-5 animate-spin" /> : <Navigation className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {mapsResult && (
            <div className="grid lg:grid-cols-3 gap-8 animate-fadeIn">
              <div className="lg:col-span-2 p-10 bg-slate-950/50 rounded-[32px] border border-slate-800/50 prose prose-invert max-w-none shadow-xl">
                <div className="mb-6 flex items-center gap-4 text-xs font-black text-red-400 uppercase tracking-widest">
                  <Star className="w-4 h-4 fill-red-400" /> Sentiment Analysis Result
                </div>
                <div dangerouslySetInnerHTML={{ __html: marked.parse(mapsResult.text) }} />
              </div>
              
              <div className="space-y-6">
                <h4 className="text-[10px] font-black text-red-400 uppercase tracking-[0.2em] flex items-center gap-2">
                  <MessageSquare className="w-3 h-3" /> Live Review Snippets
                </h4>
                <div className="space-y-4">
                  {mapsResult.chunks.flatMap(chunk => 
                    chunk.maps?.placeAnswerSources?.reviewSnippets || []
                  ).map((snippet, idx) => (
                    <div key={idx} className="p-5 bg-slate-800/20 border border-slate-700/30 rounded-2xl relative group">
                      <Quote className="w-8 h-8 absolute top-2 right-4 opacity-5 text-white" />
                      <p className="text-xs text-slate-300 italic mb-3">"{snippet.text}"</p>
                      <a 
                        href={snippet.uri} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="text-[9px] font-black uppercase text-red-400 hover:text-white transition-colors flex items-center gap-1"
                      >
                        Verify <ExternalLink className="w-2 h-2" />
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* ORIGINAL TOOLS: Friction Audit & AEO */}
      <div className="grid lg:grid-cols-2 gap-12 mb-32">
        <section className="bg-slate-900/50 border border-slate-800 rounded-[40px] p-8 md:p-12 shadow-2xl text-left flex flex-col justify-between group hover:border-cyan-400/30 transition-all">
          <div>
            <div className="flex justify-between items-start mb-4">
              <h2 className="text-3xl font-black text-white uppercase tracking-tighter italic">The Friction Audit</h2>
              <button 
                onClick={downloadAuditReport}
                className="p-2 bg-slate-800 hover:bg-cyan-400 text-slate-400 hover:text-slate-900 rounded-xl transition-all"
                title="Download ROI Certificate"
              >
                <Download className="w-5 h-5" />
              </button>
            </div>
            <p className="text-slate-400 text-sm mb-10">Quantifying structural leakage in the 2026 enterprise.</p>
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase">
                  <span>Team Size</span>
                  <span className="text-white">{teamSize} Personnel</span>
                </div>
                <input type="range" min="1" max="100" value={teamSize} onChange={(e) => setTeamSize(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 accent-cyan-400 rounded-lg appearance-none cursor-pointer" />
              </div>
              <div className="space-y-4">
                <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase">
                  <span>Manual Hours / Wk</span>
                  <span className="text-white">{hours} Hours</span>
                </div>
                <input type="range" min="1" max="40" value={hours} onChange={(e) => setHours(parseInt(e.target.value))} className="w-full h-1 bg-slate-800 accent-cyan-400 rounded-lg appearance-none cursor-pointer" />
              </div>
            </div>
          </div>
          <div className="mt-12 p-10 bg-slate-950 rounded-3xl border border-slate-800 text-center">
             <span className="text-[10px] font-black text-slate-500 uppercase mb-2 block tracking-widest">Annual Leakage</span>
             <div className="text-5xl font-black text-white tracking-tighter mb-8">${annualLoss.toLocaleString()}</div>
             <button 
              onClick={handlePlugTheLeak}
              disabled={loadingAudit}
              className="w-full bg-cyan-400 text-slate-900 py-4 rounded-xl font-black uppercase text-xs tracking-widest shadow-lg shadow-cyan-400/20 hover:bg-white transition-colors flex items-center justify-center gap-2"
             >
               {loadingAudit ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
               Plug the Leak
             </button>
          </div>
        </section>

        <section className="bg-slate-900/50 border border-slate-800 rounded-[40px] p-8 md:p-12 shadow-2xl text-left flex flex-col group hover:border-cyan-400/30 transition-all">
          <h2 className="text-3xl font-black text-white mb-4 uppercase tracking-tighter italic">AEO Architect</h2>
          <p className="text-slate-400 text-sm mb-10">Deploy roadmaps for Answer Engine dominance.</p>
          <div className="flex gap-4 bg-slate-950 p-4 rounded-3xl border border-slate-800 mb-8">
            <input 
              value={niche} 
              onChange={(e) => setNiche(e.target.value)} 
              placeholder="e.g. Zurich Real Estate" 
              className="bg-slate-900 border-none rounded-xl px-6 py-3 text-white text-sm outline-none focus:ring-1 focus:ring-cyan-400 w-full" 
            />
            <button 
              onClick={handleGenerateAEO} 
              disabled={loadingAEO || !niche} 
              className="bg-cyan-400 text-slate-900 px-6 py-3 rounded-xl font-black uppercase text-xs tracking-widest flex items-center gap-2"
            >
              {loadingAEO ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            </button>
          </div>
          {strategy && (
            <div className="flex-1 overflow-y-auto max-h-[400px] p-8 bg-slate-950 rounded-3xl border border-slate-800 prose prose-invert prose-xs custom-scrollbar">
              <div dangerouslySetInnerHTML={{ __html: marked.parse(strategy) }} />
            </div>
          )}
        </section>
      </div>

      {/* Audit Modal */}
      {showAuditModal && auditRoadmap && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 backdrop-blur-2xl bg-black/60 animate-fadeIn">
          <div className="bg-slate-950 border border-slate-800 w-full max-w-3xl rounded-[60px] shadow-3xl flex flex-col max-h-[85vh] overflow-hidden">
            <div className="p-10 border-b border-slate-900 flex justify-between items-center bg-slate-900/40">
               <div className="flex items-center gap-4">
                 <div className="p-3 bg-cyan-400/10 rounded-2xl">
                    <Zap className="w-6 h-6 text-cyan-400" />
                 </div>
                 <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Neural Recovery Roadmap</h3>
               </div>
               <button onClick={() => setShowAuditModal(false)} className="p-2 text-slate-500 hover:text-white transition-colors">
                 <X className="w-8 h-8" />
               </button>
            </div>
            <div className="p-12 overflow-y-auto flex-1 prose prose-invert max-w-none custom-scrollbar bg-slate-950/20">
               <div dangerouslySetInnerHTML={{ __html: marked.parse(auditRoadmap) }} />
            </div>
            <div className="p-10 border-t border-slate-900 text-center flex flex-col gap-2">
               <button className="w-full bg-cyan-400 text-slate-900 py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-cyan-400/20 hover:bg-white transition-all">
                  Request Full Strategic Implementation
               </button>
               <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest mt-4">
                 Values calculated for baseline organizational reclamation
               </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;
